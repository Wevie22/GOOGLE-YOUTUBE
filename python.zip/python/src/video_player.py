"""A video player class."""

from .video_library import VideoLibrary


class VideoPlayer:
    """A class used to represent a Video Player."""

    def __init__(self):
        self._video_library = VideoLibrary()
        self.isPlaying = False
        self.isPaused= False
        self.Video_Playing_id= "None"
        self.playlist_id = 0
        self.playlist_list = []
        self.videoflag = False
        
    def Video_Name(self, video_id): 
        video = self._video_library = VideoLibrary()
        return video.title
   
    def number_of_videos(self):
        num_videos = len(self._video_library.get_all_videos())
        print(f"{num_videos} videos in the library")

    def show_all_videos(self):
        """Returns all videos."""
          videos = self._video_library.get_all_videos()
        print("Here's a list of all available videos:")
        temp_list = []

        for vid in videos:

            # Convoluted way to display tags in required format
            tags ="["
            for tag in vid.tags:
                tags = tags + tag + " "
            tags = tags + "]"

            if tags != "[]":
                tags = tags[0:len(tags)-2] + "]"

            # Put all videos in a list for sorting
            temp_list += [f"{vid.title} ({vid.video_id}) {tags}"]

        # Sort the list and display
        sorted_list = sorted(temp_list)
        for x in sorted_list:
            print(x)
            
    def play_video(self, video_id):
        """Plays the respective video.

        Args:
            video_id: The video_id to be played.
        """
        video = self._video_library = VideoLibrary()
        
        try: 
           temp = video.title
           if self.isPlaying = False
              print (f"Playing video:{video.title}")
              self.isPlaying = True
              self.is Paused = False
              self.Video_Playing_id = video_id
            else:
              print(f"Stopping video:{self.Video_Name(self.Video_Playing_id}")
              print(f"Playing video:{video.title}")
              self.Video_Playing_id = video_id
              self.isPaused = False
       except: 
        print("Cannot play video: Video does not exist")
